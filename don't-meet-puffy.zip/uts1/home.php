<?php
    // mulai session
    session_start();
   if (isset($_POST['restart'])) {
		header("Location: play.php");
	}
    if (isset($_COOKIE['username'])){
        $status = true;
    } else {
        $status = false;
    }
?>

<!DOCTYPE html>
<html>
<head>
  <a href="user.php"><input type="submit" class="home" name="history" value="HISTORY"></a>
	<title>Don't Meet Puffy! - Minesweeper</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="icon" type="image/png" href="img/icon.png">
  <center><img class="title" name="title" src="img/title1.png"></img></center>
</head>

<body>
<center>

<form enctype="multipart/form-data" method="post" action="play.php">

		<?php
            if ($status == false){
        ?>
        <center><img class="hello" src="img/hello.png"></center>
		<center><input  type="text" class="username" name="username" placeholder="Username"></center>
	  
    <h1 class="username-cookie">👇Insert Your Photo👇</h1>
    <center><input type="file" class="username" value="Choose Photo" name="userfile"/><br><br>

    <center><select class="level" name="level" style="padding: 15px;">
        <option class="select" value="easy"> Easy </option>
        <option class="select" value="medium"> Medium </option>
        <option class="select" value="hard"> Hard </option>
    </center></select><br><br>    
		
    <center><input type="submit" class="submit1" name="submit1" value="START"  style="padding: 12px; font-size: 120%;" src="" ></center><br>

		<?php       
            } else {
            ?>
            <center><img class="wb" src="img/wb.png"></center>
            <?php 
          echo '<div class="lp">'.$_COOKIE['username'].'🐠</div>';
          echo '<div class="lp">Last Played ' .$_COOKIE['lasttime'].'</div>';
         ?>
         <br><br><center><input type="submit" class="submit2" name="submit2" value="START"  style="padding: auto; font-size: 120%;" src="" ></center><br>
         <center><input type="submit" class="submit0" name="submit0" value="NOT ME" src="" ></center>
        <?php       
            }
        ?>

</form>
</center>
</body>
</html>
