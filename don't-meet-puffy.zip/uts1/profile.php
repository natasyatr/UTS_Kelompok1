<?php
 include 'dbconfig.php';
 $db = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
 $id = $_GET['id'];
$query = "SELECT * FROM score WHERE id ='$id'";
$result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <a href="home.php"><input type="submit" class="home" name="home" value="🏠HOME"></a>
  <a href="user.php"><input type="submit" class="home" name="home" value="👈Back"></a>
  <title>Don't Meet Puffy! - Minesweeper</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="icon" type="image/png" href="img/icon.png">
  <center><img class="title" name="title" src="img/title1.png"></img></center>
</head>
<body><center>
    <h1 class="title-user"><center>USER PROFILE</center></h1>
        <?php
           $data = mysqli_fetch_array ($result);
           echo '<h2 class="title-user"> Username : '.$data['username']. '</h2>';
           echo "<img src = 'photo/".$data['foto']."'>";
     ?>
</body>
</html>