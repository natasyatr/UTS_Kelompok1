<?php
session_start();

if (isset($_POST['submit1'])){      
        // setting nama folder tempat upload
        $uploaddir = 'photo/';
        // tanggal dan waktu file diupload 
        $uploadtime = date('YmdHis');
        // setting nama sesuai dengan aturan (namauser-tanggal.ext)
        $uploadfile = $_POST['username'] . "-" . $uploadtime . "." . pathinfo($_FILES['userfile']['name'],PATHINFO_EXTENSION);
        // proses upload file ke folder 'photo'
        if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploaddir.$uploadfile)) {
            echo "File telah diupload";
        } else {
            echo "File gagal diupload";
        }
        // set session nama file untuk diupload ke db
        $_SESSION['filenameupload'] = $uploadfile;
        setcookie('username', $_POST['username'], time()+3600*24*7);
        header("Location: play.php");
    }

        //Menghapus cookie
    if (isset($_POST['submit0'])){
        setcookie('username', $_POST['username'], time()-3600*24*1);
        header("Location: home.php");
    }
    if (isset($_POST['submit1'])){
    if ($_POST['level'] == "easy"){
        $_SESSION['level'] = "easy";
        $_SESSION['width'] = 9;
        $_SESSION['height'] = 9;
        $_SESSION['mines'] = 10;
    }
    elseif ($_POST['level'] == "medium"){
        $_SESSION['level'] = "medium";
        $_SESSION['width'] = 16;
        $_SESSION['height'] = 16;
        $_SESSION['mines'] = 40;
    }
    elseif ($_POST['level'] == "hard"){
        $_SESSION['level'] = "hard";
        $_SESSION['width'] = 30;
        $_SESSION['height'] = 16;
        $_SESSION['mines'] = 99;
    }
}   


define('MINEGRID_WIDTH',  $_SESSION['width']);
define('MINEGRID_HEIGHT', $_SESSION['height']);
 
define('MINESWEEPER_NOT_EXPLORED', -1);
define('MINESWEEPER_MINE', $_SESSION['mines']);
define('MINESWEEPER_FLAGGED',      -3);
define('MINESWEEPER_FLAGGED_MINE', -4);
define('ACTIVATED_MINE',           -5);
 
function check_field($field) {
    if ($field === MINESWEEPER_MINE || $field === MINESWEEPER_FLAGGED_MINE) {
        return true;
    }
    else {
        return false;
    }
}
 
function explore_field($field) {
    if (!isset($_SESSION['minesweeper'][$field])
     || !in_array($_SESSION['minesweeper'][$field],
                  array(MINESWEEPER_NOT_EXPLORED, MINESWEEPER_FLAGGED))) {
        return;
    }
 
    $mines = 0;
 
    // Make reference to that long name
    $fields  = &$_SESSION['minesweeper'];
 
    // left side options
    if ($field % MINEGRID_WIDTH !== 1) {
        $mines += check_field(@$fields[$field - MINEGRID_WIDTH - 1]);
        $mines += check_field(@$fields[$field - 1]);
        $mines += check_field(@$fields[$field + MINEGRID_WIDTH - 1]);
    }
 
    // bottom and top
    $mines += check_field(@$fields[$field - MINEGRID_WIDTH]);
    $mines += check_field(@$fields[$field + MINEGRID_WIDTH]);
 
    // right side options
    if ($field % MINEGRID_WIDTH !== 0) {
        $mines += check_field(@$fields[$field - MINEGRID_WIDTH + 1]);
        $mines += check_field(@$fields[$field + 1]);
        $mines += check_field(@$fields[$field + MINEGRID_WIDTH + 1]);
    }
 
    $fields[$field] = $mines;
 
    if ($mines === 0) {
        if ($field % MINEGRID_WIDTH !== 1) {
            explore_field($field - MINEGRID_WIDTH - 1);
            explore_field($field - 1);
            explore_field($field + MINEGRID_WIDTH - 1);
        }
 
        explore_field($field - MINEGRID_WIDTH);
        explore_field($field + MINEGRID_WIDTH);
 
        if ($field % MINEGRID_WIDTH !== 0) {
            explore_field($field - MINEGRID_WIDTH + 1);
            explore_field($field + 1);
            explore_field($field + MINEGRID_WIDTH + 1);
        }
    }
}
 
 
if (!isset($_SESSION['minesweeper'])) {
    // Fill grid with not explored tiles
    $_SESSION['minesweeper'] = array_fill(1,
                                         MINEGRID_WIDTH * MINEGRID_HEIGHT,
                                         MINESWEEPER_NOT_EXPLORED);
 
    $number_of_mines = $_SESSION['mines'];
 
    // generate mines randomly
    $random_keys = array_rand($_SESSION['minesweeper'], $number_of_mines);
 
    foreach ($random_keys as $key) {
        $_SESSION['minesweeper'][$key] = MINESWEEPER_MINE;
    }
 
    // to make calculations shorter use SESSION variable to store the result
    $_SESSION['numberofmines'] = $number_of_mines;
}
 
if (isset($_GET['explore'])) {
    if(isset($_SESSION['minesweeper'][$_GET['explore']])) {
        switch ($_SESSION['minesweeper'][$_GET['explore']]) {
            case MINESWEEPER_NOT_EXPLORED:
                explore_field($_GET['explore']);
                break;
            case MINESWEEPER_MINE:
                $lost = 1;
                $_SESSION['minesweeper'][$_GET['explore']] = ACTIVATED_MINE;
                break;
            default:
                break;
        }
    }
    else {
        die('Tile doesn\'t exist.');
    }
}
elseif (isset($_GET['flag'])) {
    if(isset($_SESSION['minesweeper'][$_GET['flag']])) {
        $tile = &$_SESSION['minesweeper'][$_GET['flag']];
        switch ($tile) {
            case MINESWEEPER_NOT_EXPLORED:
                $tile = MINESWEEPER_FLAGGED;
                break;
            case MINESWEEPER_MINE:
                $tile = MINESWEEPER_FLAGGED_MINE;
                break;
            case MINESWEEPER_FLAGGED:
                $tile = MINESWEEPER_NOT_EXPLORED;
                break;
            case MINESWEEPER_FLAGGED_MINE:
                $tile = MINESWEEPER_MINE;
                break;
            default:
                break;
        }
    }
    else {
        die('Tile doesn\'t exist.');
    }
}
 
// Check if the player won...
if (!in_array(MINESWEEPER_NOT_EXPLORED, $_SESSION['minesweeper'])
 && !in_array(MINESWEEPER_FLAGGED,      $_SESSION['minesweeper'])) {
    $won = true;
}
?>




<!DOCTYPE html>
<title>Don't Meet Puffy! - Minesweeper</title>
<body class="bg"></body>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" type="image/png" href="img/icon.png">

    <center><img class="title" name="title" src="img/title1.png"></img></center>
    
    <center>

    <?php
        // tampilkan username dari cookie
        echo '<br><div class="username-cookie">Good Luck, '.$_COOKIE['username'].'!✨</div>';
    ?>
     <?php
       setcookie('lasttime', date('d/m/Y H:i'), time()+3600*24*7);
       include "dbconfig.php";
            // connect db
            $db = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
            // set query
            $query = "INSERT INTO score(username, playtime, foto)
            VALUES ('".$_COOKIE['username']."','".date('Y-m-d H:i:s')."','".$_SESSION['filenameupload']."')";
            // run the query
            $result = mysqli_query($db, $query);
    ?>

<style>
table { 
    border: 20px solid;
    border-style: ridge;
    border-color: #7ED6DD;
}

td, a {
    text-align : center;
    width : 1em;
    height : 1em;
    background-color: #D0DF6F;
}

a {
    display : block;
    color : blue;
    text-decoration : none;
    font-size : 2em;
    font-color : green;
}
</style>


<script>
function flag(number, e) {
    if (e.which === 2 || e.which === 3) {
        location = '?flag=' + number;
        return false;
    }
}
</script>




<?php
    echo '<div class="mines-field">❗This field contains '.$_SESSION['mines'].' PUFFY❗</div>';
?>
<table border="1">
<?php

$mine_copy = $_SESSION['minesweeper'];
 
for ($x = 1; $x <= MINEGRID_HEIGHT; $x++) {
    echo '<tr>';
    for ($y = 1; $y <= MINEGRID_WIDTH; $y++) {
        echo '<td>';
 
        $number = array_shift($mine_copy);
        switch ($number) {
            case MINESWEEPER_FLAGGED:
            case MINESWEEPER_FLAGGED_MINE:
                if (!empty($lost) || !empty($won)) {
                    if ($number === MINESWEEPER_FLAGGED_MINE) {
                    ?>
                    <img src="img/bom.png">
                    <?php
                    }
                    else {
                    ?>
                    <a href="" class="cell"></a>
                    <?php
                    }
                }
                else {
                    echo '<a href=# onmousedown="return flag(',
                         ($x - 1) * MINEGRID_WIDTH + $y,
                         ',event)" oncontextmenu="return false">🚩</a>';
                }
                break;
            case ACTIVATED_MINE:
                ?>
                <img src="img/bom.png">
                <?php
                break;
            case MINESWEEPER_MINE:
            case MINESWEEPER_NOT_EXPLORED:
 
                if (!empty($lost)) {
                    if ($number === MINESWEEPER_MINE) {
                    ?>
                    <img src="img/bom.png">
                    <?php
                    }
                    else {
                    echo '<a></a>';
                    }
                }
                elseif (!empty($won)) {
                ?>
                <img src="img/bom.png">
                <?php
                }
                else {
                    echo '<a href="?explore=',
                         ($x - 1) * MINEGRID_WIDTH + $y,
                         '" onmousedown="return flag(',
                         ($x - 1) * MINEGRID_WIDTH + $y,
                         ',event)" oncontextmenu="return false"></a>';
                }
                break;
            case 0:
                ?>
                <a href="" class="cell"></a>
                <?php
                break;
            default:
                echo '<a class="number cell">', $number, '</a>';
                break;
        }
    }
}
?>
</table>



<?php  
    if (!empty($lost)) {
        unset($_SESSION['minesweeper']);
    ?>
     <img class="lost" name="lost" src="img/lost.png">
    <?php 
        } elseif (!empty($won)) {
            unset($_SESSION['minesweeper']);
            ?>
            <img class="won" name="won" src="img/won.png">
            <?php 
        }

?>

<form method="POST" action="home.php">
    <input type="submit" class="newgame" name="new game" value="NEW GAME" src=""></input>
    <input type="submit" class="restart" name="restart" value="RESTART" src=""></input>
</form>

</center>
