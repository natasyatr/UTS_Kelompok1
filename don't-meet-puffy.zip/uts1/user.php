<?php
 include 'dbconfig.php';
 $db = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
$query = "SELECT * FROM score";
$result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <a href="home.php"><input type="submit" class="home" name="home" value="🏠HOME"></a>
  <title>Don't Meet Puffy! - Minesweeper</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="icon" type="image/png" href="img/icon.png">
  <center><img class="title" name="title" src="img/title1.png"></img></center>
</head>

<body><center>
    <h1 class="title-user"><center>HISTORY</center></h1>
    <table border="1" class="subtitle">
        <tr>
            <th>Username</th>
            <th>Playtime</th>
        </tr>
        <style>
table { 
    border: 10px solid;
    border-style: ridge;
    border-color: #7ED6DD;
    background-color: #BBEBAF;
}

td {
    text-align : center;
    width : 5cm;
    height : 1cm;
    background-color: #D0DF6F;

}
</style>
        <?php
            while ($data = mysqli_fetch_array ($result)){
        echo "<tr>";
            echo "<td><a href = 'profile.php?id=".$data['id'].">".$data['username'];
           echo "</td>";
           echo "<td>".$data['playtime'];
        echo "</tr>";
         }
     ?>

    </table>
</body>
</html>